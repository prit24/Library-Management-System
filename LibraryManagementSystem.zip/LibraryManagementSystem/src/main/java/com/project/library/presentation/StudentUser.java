package com.project.library.presentation;

import com.project.library.entity.Student;

public interface StudentUser
{

    void registerStudent();
    int getStudentById();
    Student inputStudentLogin();
    //void inputGetStudentByUserName();
    void updateStudent();
    void bookIssue();
    void viewBorrowedDetails();

}
