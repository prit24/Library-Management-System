package com.project.library.presentation;

import com.project.library.entity.Book;
import com.project.library.entity.BookIssue;
import com.project.library.entity.Student;
import com.project.library.service.BookIssueService;
import com.project.library.service.BookIssueServiceImpl;
import com.project.library.service.StudentService;
import com.project.library.service.StudentServiceImpl;
import com.project.library.validation.Validation;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class StudentUserImpl implements StudentUser {
    private Scanner sc = new Scanner(System.in);
    private StudentService studentService = new StudentServiceImpl();
    private BookIssueUser bookIssueUser = new BookIssueUserImpl();
    private static BookIssueService  bookIssueService = new BookIssueServiceImpl();
    private BookUser bookUser = new BookUserImpl();
    private  Integer studId, issueId;
    private static Student student;
    private String studPassword;


    @Override
    public void registerStudent() {
        System.out.println("Enter User  Name:");
        String studName = sc.nextLine();
        while (!Validation.isValidStudName(studName)) {
            System.out.println("Invalid user Name. \nPlease enter a valid User Name:");
            studName = sc.next();
        }

        System.out.println("Enter Student Email:");
        String studEmail = sc.next();
        while (!Validation.isValidEmail(studEmail)) {
            System.out.println("Invalid email. \nPlease enter a valid email:");
            studEmail = sc.next();
        }


        System.out.println("Enter Student Contact No:");
        String studContactNo = sc.next();
        while (!Validation.isValidMobileNumber(studContactNo)) {
            System.out.println("Invalid mobile number. \nPlease enter a valid mobile number:");
            studContactNo = sc.next();
        }

        System.out.println("Enter Student Address:");
        String studAddress = sc.next();


        System.out.println("Enter Student Password:");
        String studPassword = sc.next();
        while (!Validation.isValidPassword(studPassword)) {
            System.out.println("Invalid password. Please enter a valid password:");
            studPassword = sc.next();
        }

        student = new Student();
        student.setStudName(studName);
        student.setStudEmail(studEmail);
        student.setStudContactNo(studContactNo);
        student.setStudAddress(studAddress);
        student.setStudPassword(studPassword);

        StudentService studentService = new StudentServiceImpl();
        System.out.println(studentService.registerStudent(student));

    }

    @Override
    public int getStudentById() {

        if (student != null) {
            System.out.println("Student Details:");
            System.out.printf("%-15s | %-20s | %-30s | %-15s | %-30s | %-15s%n",
                    "ID", "Name", "Email", "Contact No", "Address", "Password");
            System.out.printf("%-15s | %-20s | %-30s | %-15s | %-30s | %-15s%n",
                    student.getStudId(), student.getStudName(), student.getStudEmail(),
                    student.getStudContactNo(), student.getStudAddress(), student.getStudPassword());
        } else {
            System.out.println("Student not found with ID: " + studId);
        }
        return 0;
    }






    @Override
    public Student inputStudentLogin() {
        System.out.println("******** Login Page *********");

        System.out.println("Enter User Id : ");
        studId = sc.nextInt();

        System.out.println("Student Password : ");
        studPassword = sc.next();

        student = studentService.getStudentById(studId);

        if (student != null && studPassword.equals(student.getStudPassword())) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Login failed....\nPlease try again............\n");
            student = null;
        }

        return student;

    }

    @Override
    public void updateStudent()
    {
        if (student != null) {
            System.out.println("Update Student Information:");
            System.out.println("1. Update Name");
            System.out.println("2. Update Email");
            System.out.println("3. Update Contact Number");
            System.out.println("4. Update Address");
            System.out.println("5. Update Password");
            System.out.println("6. Go back to the main menu");
            System.out.print("\nPlease enter your choice (1-6) : ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.println("Enter new Name:");
                    String newName = sc.nextLine();
                    while (!Validation.isValidStudName(newName)) {
                        System.out.println("Invalid name. \nPlease enter a valid name:");
                        newName = sc.nextLine();
                    }
                    student.setStudName(newName);
                    break;

                case 2:
                    System.out.println("Enter new Email:");
                    String newEmail = sc.next();
                    while (!Validation.isValidEmail(newEmail)) {
                        System.out.println("Invalid email. \nPlease enter a valid email:");
                        newEmail = sc.next();
                    }
                    student.setStudEmail(newEmail);
                    break;

                case 3:
                    System.out.println("Enter new Contact Number:");
                    String newContactNo = sc.next();
                    while (!Validation.isValidMobileNumber(newContactNo)) {
                        System.out.println("Invalid mobile number. \nPlease enter a valid mobile number:");
                        newContactNo = sc.next();
                    }
                    student.setStudContactNo(newContactNo);
                    break;

                case 4:
                    System.out.println("Enter new Address:");
                    String newAddress = sc.nextLine();
                    student.setStudAddress(newAddress);
                    break;

                case 5:
                    System.out.println("Enter new Password:");
                    String newPassword = sc.next();
                    while (!Validation.isValidPassword(newPassword)) {
                        System.out.println("Invalid password. Please enter a valid password:");
                        newPassword = sc.next();
                    }
                    student.setStudPassword(newPassword);
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
            studentService.updateStudent(student);
            System.out.println("Student information updated successfully!");
        } else {
            System.out.println("Student not found. Please log in first.");
        }
    }


    @Override
    public void bookIssue() {
        bookUser.inputGetAllBooks();
        System.out.println("\n");

        System.out.println("Student User is : " + studId);
        bookIssueUser.inputIssueBook(studId);

    }

    @Override
    public void viewBorrowedDetails() {
        List<BookIssue> borrowedBooks = bookIssueService.getIssuedBookbyStudent(student);


        if (borrowedBooks.isEmpty()) {
            System.out.println("You have not borrowed any books.");
        } else {
            System.out.println("Borrowed Book Details:");
            System.out.printf("%-15s |%-15s |%-15s | %-20s | %-15s | %-15s | %-15s%n",
                    "Student Id" ,"Issue Id","Book ID", "Book Name", "Issue Date", "Due Date", "Return Date");

            for (BookIssue bookIssue : borrowedBooks) {
                Book book = bookIssue.getBook();
                LocalDate issueDate = bookIssue.getIssueDate();
                LocalDate dueDate = bookIssue.getDueDate();
                LocalDate returnDate = bookIssue.getReturnDate();

                System.out.printf("%-15s |%-15s |%-15s | %-20s | %-15s | %-15s | %-15s%n",
                        student.getStudId(),bookIssue.getIssueId(), book.getBookId(), book.getBookName(), issueDate, dueDate,
                        (returnDate != null) ? returnDate : "Not Returned");
            }

        }

    }
}


