package com.project.library.dao;

import com.project.library.entity.Admin;

import java.util.List;

public interface AdminDao
{
    String registerAdmin(Admin admin);
    Admin getAdminById(Integer adminId);
    String updateAdminInfo(Integer adminId);
    List<Admin> showAllAdmin();
    Admin deleteAdmin(Integer adminId);
}
