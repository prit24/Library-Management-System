package com.project.library.service;

import com.project.library.dao.BookDao;
import com.project.library.dao.BookDaoImpl;
import com.project.library.entity.Book;

import java.util.List;

public class BookServiceImpl implements BookService{
    BookDao bookDao = new BookDaoImpl();

    @Override
    public String registeredBook(Book book)
    {
        return bookDao.registeredBook(book);
    }

    @Override
    public List<Book> getAllBooks()
    {
        return  bookDao.getAllBooks();
    }

    @Override
    public Book getBookById(Integer bookId)
    {
        return bookDao.getBookById(bookId);
    }

    @Override
    public List<Book> getAllBookByName(String bookName)
    {
        return  bookDao.getAllBookByName(bookName);
    }

    @Override
    public List<Book> getAllBookByType(String bookType)
    {
        return bookDao.getAllBookByType(bookType);
    }

    @Override
    public List<Book> getAllBooksByAuthor(String authorName)
    {
        return bookDao.getAllBooksByAuthor(authorName);
    }
    @Override
    public String updateStock(Book book)
    {
        return bookDao.updateStock(book);
    }

}
