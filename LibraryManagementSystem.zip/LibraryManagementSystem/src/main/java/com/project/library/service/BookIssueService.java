package com.project.library.service;

import com.project.library.entity.BookIssue;
import com.project.library.entity.Student;

import java.util.List;

public interface BookIssueService
{
    public String issueBook(BookIssue bookIssue);
    public String returnBook(BookIssue bookIssue);
    BookIssue getBookIssuedById(Integer issueId);
    List<BookIssue> getIssuedBook();
    List<BookIssue> displayUnissuedBook();


    BookIssue findRecordByIssueId(Integer issueId);
    String confirmIssueBook(BookIssue bookIssue);
    List<BookIssue>  displayAllFineStudent();
    public List<BookIssue> payFine() ;
    List<BookIssue> unReturnedBooks();
    List<BookIssue> unReturnedBooksByStudent();
    List<BookIssue> getIssuedBookbyStudent(Student student);
}
