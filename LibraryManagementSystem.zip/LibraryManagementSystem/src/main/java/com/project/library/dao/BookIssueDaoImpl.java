package com.project.library.dao;

import com.project.library.entity.Student;
import com.project.library.presentation.BookUser;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import com.project.library.entity.BookIssue;
import jakarta.persistence.Query;

import java.util.List;
import jakarta.persistence.TypedQuery;

public class BookIssueDaoImpl implements BookIssueDao {
    EntityManager entityManager=MyConnection.getEntityManagerObject();
    EntityTransaction entityTransaction=entityManager.getTransaction();
    Query query;

    @Override
    public String issueBook(BookIssue bookIssue) {
        entityTransaction.begin();
        entityManager.persist(bookIssue);
        entityTransaction.commit();
        return "Book issue request sended to the Admin";
    }

    @Override
    public String returnBook(BookIssue bookIssue) {
        BookIssue bookIssue1=entityManager.find(BookIssue.class, bookIssue.getIssueId());
        if(bookIssue1!=null) {
            entityTransaction.begin();
            bookIssue1.setReturnDate(bookIssue.getReturnDate());
            bookIssue1.setBookStatus(bookIssue.getBookStatus());
            entityTransaction.commit();
        }
        return "Book returned";
    }


    @Override
    public BookIssue getBookIssuedById(Integer issueId) {
        BookIssue bookIssue=entityManager.find(BookIssue.class, issueId);
        return bookIssue;
    }

    @Override
    public List<BookIssue> getIssuedBook() {
        String jpql="select b from BookIssue b";
        query=entityManager.createQuery(jpql);
        List<BookIssue> list=query.getResultList();
        return list;
    }

    @Override
    public List<BookIssue> displayUnissuedBook() {
        query=entityManager.createQuery("select bi from BookIssue bi where bi.bookStatus='Not Issue'");
        return query.getResultList();
    }

    @Override
    public BookIssue findRecordByIsuueId(Integer issueId) {

        return entityManager.find(BookIssue.class, issueId);
    }

    @Override
    public String confirmIssueBook(BookIssue bookIssue) {
       BookIssue bookIssue1 = entityManager.find(BookIssue.class, bookIssue.getIssueId());
       entityTransaction.begin();
       bookIssue1.setBookStatus(bookIssue.getBookStatus());
       entityTransaction.commit();
       entityManager.clear();
       return "Book is confirmed";
    }

    @Override
    public List<BookIssue> displayAllFineStudent()
    {
        query=entityManager.createQuery("select bi from BookIssue bi where bi.fine > 0");
        return query.getResultList();
    }

    @Override
    public List<BookIssue> payFine()
    {

        return null;
    }

    @Override
    public List<BookIssue> unReturnedBooks() {
        query=entityManager.createQuery("select bi from BookIssue bi where bi.bookStatus='ISSUED'");
        return query.getResultList();
    }

    @Override
    public List<BookIssue> unReturnedBooksByStudent(Student student)
    {

        String jpql = "SELECT bi FROM BookIssue bi WHERE bi.student = :studId AND bi.bookStatus = 'ISSUED'";

        TypedQuery<BookIssue> query = entityManager.createQuery(jpql, BookIssue.class);
        query.setParameter("studId", student);

        return query.getResultList();
    }

}
