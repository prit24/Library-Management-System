package com.project.library.service;

import com.project.library.dao.BookIssueDao;
import com.project.library.dao.BookIssueDaoImpl;
import com.project.library.entity.Admin;
import com.project.library.entity.Book;
import com.project.library.entity.BookIssue;
import com.project.library.entity.Student;

import java.util.Iterator;
import java.util.List;

public class BookIssueServiceImpl implements BookIssueService {

    private static BookIssueDao bookIssueDao = new BookIssueDaoImpl();
    private static Admin admin = new Admin();
    private  static Student student = new Student();
    private static Book book = new Book();
    private static String  BIStudentId = "NULL", BIBookId="NULL";
    public static Integer BIAdminId ;


    @Override
    public String issueBook(BookIssue bookIssue) {

        return bookIssueDao.issueBook(bookIssue);
    }

    @Override
    public String returnBook(BookIssue bookIssue)
    {

        return bookIssueDao.returnBook(bookIssue);
    }

    @Override
    public BookIssue getBookIssuedById(Integer issueId) {

        return bookIssueDao.getBookIssuedById(issueId);
    }

    @Override
    public List<BookIssue> getIssuedBook() {

       return bookIssueDao.getIssuedBook();

    }

    @Override
    public List<BookIssue> getIssuedBookbyStudent(Student student) {

        // return bookIssueDao.getIssuedBook();
        return bookIssueDao.unReturnedBooksByStudent(student);
    }

    @Override
    public List<BookIssue> displayUnissuedBook() {
        List<BookIssue> bookIssueList =  bookIssueDao.displayUnissuedBook();

        if(bookIssueList!=null) {
            if(!bookIssueList.isEmpty()) {
                Iterator<BookIssue> itr = bookIssueList.iterator();
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                        "Book Issue Id", "Book Issue Status", "Due Date", "Fine", "Issue Date", "Return Date", "Admin Id", "Book Id", "Student Id");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");
                while(itr.hasNext()) {
                    BookIssue bookIssue = itr.next();
                    Admin admin = bookIssue.getAdmin();
                    if(admin!=null) BIAdminId=admin.getAdminId();
                    Student student = bookIssue.getStudent();
                    if(student!=null) BIStudentId=student.getStudId()+"";
                    Book book = bookIssue.getBook();
                    if(book!=null) BIBookId = book.getBookId()+"";
                    System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                            bookIssue.getIssueId(), bookIssue.getBookStatus(), bookIssue.getDueDate(), bookIssue.getFine(),
                            bookIssue.getIssueDate(), bookIssue.getReturnDate(), BIAdminId, BIBookId, BIStudentId);
                }
            }
            else System.out.println("Sorry! No Book Issue is available");
        }
        else System.out.println("Something went wrong");

        //return bookIssueList;
         return bookIssueDao.displayUnissuedBook();
    }


    @Override
    public BookIssue findRecordByIssueId(Integer issueId)
    {

        return bookIssueDao.findRecordByIsuueId(issueId);
    }

    @Override
    public String confirmIssueBook(BookIssue bookIssue)
    {

        return bookIssueDao.confirmIssueBook(bookIssue);
    }

    @Override
    public List<BookIssue> displayAllFineStudent()
    {
        return bookIssueDao.displayAllFineStudent();
    }


    @Override
    public List<BookIssue> payFine() {
        return bookIssueDao.payFine();
    }

    @Override
    public List<BookIssue> unReturnedBooks()
    {
        List<BookIssue> bookIssueList =  bookIssueDao.unReturnedBooks();

        if(bookIssueList!=null) {
            if(!bookIssueList.isEmpty()) {
                Iterator<BookIssue> itr = bookIssueList.iterator();
                System.out.println("Unreturned books : ");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                        "Book Issue Id", "Book Issue Status", "Due Date", "Fine", "Issue Date", "Return Date", "Admin Id", "Book Id", "Student Id");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");

                while(itr.hasNext()) {
                    BookIssue bookIssue = itr.next();
                    Admin admin = bookIssue.getAdmin();
                    if(admin!=null) BIAdminId=admin.getAdminId();
                    Student student = bookIssue.getStudent();
                    if(student!=null) BIStudentId=student.getStudId()+"";
                    Book book = bookIssue.getBook();
                    if(book!=null) BIBookId = book.getBookId()+"";
                    System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                            bookIssue.getIssueId(), bookIssue.getBookStatus(), bookIssue.getDueDate(), bookIssue.getFine(),
                            bookIssue.getIssueDate(), bookIssue.getReturnDate(), BIAdminId, BIBookId, BIStudentId);
                }
            }
            else System.out.println("Sorry! No Book Issue is available");
        }
        else System.out.println("Something went wrong");
        return bookIssueDao.unReturnedBooks();
    }







    public List<BookIssue> unReturnedBooksByStudent() {
        List<BookIssue> bookIssueList = bookIssueDao.unReturnedBooksByStudent(student);

        if (bookIssueList != null) {
            if (!bookIssueList.isEmpty()) {
                Iterator<BookIssue> itr = bookIssueList.iterator();
                System.out.println("Unreturned books : ");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                        "Book Issue Id", "Book Issue Status", "Due Date", "Fine", "Issue Date", "Return Date", "Admin Id", "Book Id", "Student Id");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------");

                while (itr.hasNext()) {
                    BookIssue bookIssue = itr.next();
                    Admin admin = bookIssue.getAdmin();
                    if (admin != null) BIAdminId = admin.getAdminId();
                    Student student = bookIssue.getStudent();
                    if (student != null) BIStudentId = student.getStudId() + "";
                    Book book = bookIssue.getBook();
                    if (book != null) BIBookId = book.getBookId() + "";
                    System.out.printf("%-15s | %-18s | %-10s | %-8s | %-18s | %-18s | %-8s | %-8s | %-10s%n",
                            bookIssue.getIssueId(), bookIssue.getBookStatus(), bookIssue.getDueDate(), bookIssue.getFine(),
                            bookIssue.getIssueDate(), bookIssue.getReturnDate(), BIAdminId, BIBookId, BIStudentId);
                }
            } else {
                System.out.println("No unreturned books for the student.");
            }
        } else {
            System.out.println("Something went wrong");
        }
        return bookIssueList;
    }

}
