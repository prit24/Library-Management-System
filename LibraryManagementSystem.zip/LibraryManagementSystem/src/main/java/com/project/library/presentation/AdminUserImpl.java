package com.project.library.presentation;


import com.project.library.entity.Admin;
import com.project.library.entity.Book;
import com.project.library.entity.Student;
import com.project.library.service.AdminService;
import com.project.library.service.AdminServiceImpl;
import com.project.library.validation.Validation;

import java.util.List;
import java.util.Scanner;

public class AdminUserImpl implements AdminUser {
    private static Scanner sc = new Scanner(System.in);
    private static AdminService adminService = new AdminServiceImpl();
    private static BookIssueUser bookIssueUser = new BookIssueUserImpl();
    private static Admin admin = new Admin();
    Integer adminId;
    String adminPassword;
    @Override
    public void registerAdmin() {
        System.out.println("Enter Admin Name:");
        String adminName = sc.next();

        System.out.println("Enter Admin Email:");
        String adminEmail = sc.next();

        System.out.println("Enter Admin Contact No:");
        String adminContactNo = sc.next();

        System.out.println("Enter Admin Address:");
        String adminAddress = sc.next();

        System.out.println("Enter Admin Password:");
        String adminPassword = sc.next();

        //admin = new Admin();
        admin.setAdminName(adminName);
        admin.setAdminEmail(adminEmail);
        admin.setAdminContactNo(adminContactNo);
        admin.setAdminAddress(adminAddress);
        admin.setAdminPassword(adminPassword);


        System.out.println(adminService.registerAdmin(admin));
    }

    @Override
    public void updateAdminInfo()
    {
        System.out.println("Enter Admin ID to Update:");
        adminId = sc.nextInt();
        Admin admin = adminService.getAdminById(adminId);

        if (admin != null) {
            System.out.println("Enter Admin Name:");
            String adminName = sc.next();

            System.out.println("Enter Admin Email:");
            String adminEmail = sc.next();

            System.out.println("Enter Admin Contact No:");
            String adminContactNo = sc.next();

            System.out.println("Enter Admin Address:");
            String adminAddress = sc.next();

            System.out.println("Enter Admin Password:");
            String adminPassword = sc.next();

            //admin = new Admin();
            admin.setAdminName(adminName);
            admin.setAdminEmail(adminEmail);
            admin.setAdminContactNo(adminContactNo);
            admin.setAdminAddress(adminAddress);
            admin.setAdminPassword(adminPassword);
            System.out.println(adminService.updateAdminInfo(adminId));
        }
        else
        {
            System.out.println("Student not found with ID: " + adminId);
        }


    }

    @Override
    public void showAllAdmin()
    {
        List<Admin> allAdmins = adminService.showAllAdmin();

        if (!allAdmins.isEmpty()) {
            System.out.println("All Admins:");

            for (Admin admin : allAdmins) {
                System.out.println("Admin ID\tAdmin Name\t\t\tAdmin Email\t\t\tAdmin Contact No\t\t\tAdmin Address\t\t\tPassword");
                System.out.println( admin.getAdminId() +"\t"
                                + admin.getAdminName() +"\t\t\t"
                                + admin.getAdminEmail()+"\t\t\t"
                                + admin.getAdminContactNo() +"\t\t\t"
                                + admin.getAdminAddress()+"\t\t\t"
                                + admin.getAdminPassword());
                System.out.println("----------------------");
            }
        } else {
            System.out.println("There is no admin.");
        }


    }

    @Override
    public void deleteAdmin()
    {
        admin = adminService.getAdminById(adminId);

        if (admin != null) {
            adminService.deleteAdmin(adminId);
            System.out.println("Admin deleted successfully");

        } else
        {
            System.out.println("Admin not found with ID: " + adminId);
        }

    }

    @Override
    public void getAdminById() {
        System.out.println("Admin ID: ");
        adminId = sc.nextInt();
        AdminService adminService = new AdminServiceImpl();
        admin = adminService.getAdminById(adminId);

        if (admin != null) {
            System.out.println("Admin Details:");
            System.out.println("Admin ID: " + admin.getAdminId());
            System.out.println("Name: " + admin.getAdminName());
            System.out.println("Email: " + admin.getAdminEmail());
            System.out.println("Contact No: " + admin.getAdminContactNo());
            System.out.println("Address: " + admin.getAdminAddress());
            System.out.println("Password: " + admin.getAdminPassword());
        } else {
            System.out.println("Admin not found with ID: " + adminId);
        }
    }

    @Override
    public Admin inputAdminLogin() {
        System.out.println("******** Login Page *********");

        System.out.println("Admin Id : ");
         adminId = sc.nextInt();
         //if(Validation.isValidUserName(adminId))
         {
             sc.nextLine();

             System.out.println("Admin Password : ");
             adminPassword = sc.nextLine();

             admin = adminService.getAdminById(adminId);

             if (admin != null && adminPassword.equals(admin.getAdminPassword())) {
                 System.out.println("Login successful!");
             } else {
                 System.out.println("Login failed....\nPlease try again............\n");
                 admin = null;
             }

             return admin;
         }}

    @Override
    public void inputConfirmIssueBook()
    {
        bookIssueUser.inputConfirmIssueBook(admin);

    }

}
