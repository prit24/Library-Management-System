package com.project.library.presentation;

import java.time.LocalDate;

public interface BookUser
{
    void inputRegisteredBook();
    void inputGetAllBooks();
    void inputGetBookById();
    void inputGetBookByName();
    void inputGetBookByType();
    void inputGetBookByAuther();
    void inputUpdateStock();


}
