package com.project.library.validation;

public class Validation
{
    public static boolean isValidUserName(String userName)
    {
        String usernameFormat = "^[A-Za-z0-9_@\\-]+$";
        return userName.matches(usernameFormat);
    }

    public static boolean isValidStudName(String studName) {
        String fullNameFormat = "^[A-Za-z]+(\\s[A-Za-z]+)*$";
        return studName.matches(fullNameFormat);
    }
    public static boolean isValidPassword(String password) {
        String passwordFormat = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return password.matches(passwordFormat);
    }
    public static boolean isValidEmail(String email) {
        String emailFormat = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$";
        return email.matches(emailFormat);
    }
    public static boolean isValidMobileNumber(String mobileNumber)
    {
        String mobileNumberFormat = "^[6-9]\\d{9}$";
        return mobileNumber.matches(mobileNumberFormat);
    }
    public static boolean isValidAddress(String address) {

        String addressFormat = "^[\\w\\s]+, [\\w\\s]+, \\w{2}, (?:\\d{5}|[1-9]\\d{2}\\s?\\d{3})$";

        String smallAddressFormat = "^[\\w\\s,.-]+, [\\w\\s]+, [\\w\\s]+, \\w{2}, (?:\\d{5}|[1-9]\\d{2}\\s?\\d{3})$";
        String mediumAddressFormat = "^[\\w\\s,.-]+, [\\w\\s]+, [\\w\\s]+, \\w{2}, (?:\\d{5}|[1-9]\\d{2}\\s?\\d{3})$";
        String longAddressFormat = "^[\\w\\s,.-]+, [\\w\\s]+, [\\w\\s]+, \\w{2}, (?:\\d{5}|[1-9]\\d{2}\\s?\\d{3})$";


        return address.matches(addressFormat)|| address.matches(smallAddressFormat) || address.matches(mediumAddressFormat) || address.matches(longAddressFormat);
    }



}
