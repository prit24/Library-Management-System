package com.project.library.presentation;
import com.project.library.entity.BookIssue;
import com.project.library.entity.Admin;
import java.util.List;

public interface BookIssueUser
{
    List<BookIssue> inputIssueBook(Integer studId);
    void inputReturnBook();
    void inputGetIssuedBook();
    void inputgetBookIssuedById();
    void inputConfirmIssueBook(Admin admin);
    void displayUnissuedBook();
    void payFine();
    void displayAllFineStudent() ;
    void unReturnedBooks();
    List<BookIssue> unReturnedBooksByStudent();
    void updateStockOnReturn();
    void viewBorrowedDetails(Integer studId);



}
