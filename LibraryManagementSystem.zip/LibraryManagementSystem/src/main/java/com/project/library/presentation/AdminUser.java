package com.project.library.presentation;

import com.project.library.entity.Admin;

public interface AdminUser
{
    void registerAdmin();
    void updateAdminInfo();
    void showAllAdmin();
    void deleteAdmin();
    void getAdminById();
    Admin inputAdminLogin();

    void  inputConfirmIssueBook();
}
