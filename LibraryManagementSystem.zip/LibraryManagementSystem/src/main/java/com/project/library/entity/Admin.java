package com.project.library.entity;

import jakarta.persistence.*;

import java.util.List;
@Entity
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer adminId;
    @Column(length = 50)
    private String adminName;
    @Column(length = 50)
    private String adminEmail;
    @Column(length = 20)
    private String adminContactNo;
    @Column(length = 20)
    private String adminAddress;
    @Column(length = 20)
    private String adminPassword;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "admin")
    private List<BookIssue> bookIssue;














    public Integer getAdminId() {
        return adminId;
    }

    public void setAdminId(Integer adminId) {
        this.adminId = adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public String getAdminContactNo() {
        return adminContactNo;
    }

    public void setAdminContactNo(String adminContactNo) {
        this.adminContactNo = adminContactNo;
    }

    public String getAdminAddress() {
        return adminAddress;
    }

    public void setAdminAddress(String adminAddress) {
        this.adminAddress = adminAddress;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    public List<BookIssue> getBookIssue() {
        return bookIssue;
    }

    public void setBookIssue(List<BookIssue> bookIssue) {
        this.bookIssue = bookIssue;
    }
}
