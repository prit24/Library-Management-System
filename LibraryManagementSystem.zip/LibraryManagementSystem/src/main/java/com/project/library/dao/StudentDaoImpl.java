package com.project.library.dao;

import com.project.library.entity.Student;
;
import jakarta.persistence.EntityManager;

import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.List;


public class StudentDaoImpl implements StudentDao{
    EntityManager entityManager=MyConnection.getEntityManagerObject();
    EntityTransaction entityTransaction=entityManager.getTransaction();
    Query query;
    @Override
    public String registerStudent(Student student) {
        entityTransaction.begin();
        entityManager.persist(student);
        entityTransaction.commit();

        return "Student Registration  done\nStudentId :"+student.getStudId();
    }

    @Override
    public Student getStudentById(Integer studId) {
        if (studId != null) {
            return entityManager.find(Student.class, studId);
        } else {
            System.out.println("Invalid Student Id \nstudent Id is null\n\n");
            return null;
        }
    }

    @Override
    public String updateStudentFine(Student student)
    {
//        String jpql = "update  Student s set s.totalFine = ?1 where s.studId = ?2";
//        entityTransaction.begin();
//        entityManager.createQuery(jpql).setParameter(1,student.getTotalFine()).setParameter(2,student.getStudId()).executeUpdate();
//        entityTransaction.commit();
//        return "Student Fine Updated....";
        String jpql = "update Student s set s.totalFine = ?1 where s.studId = ?2";

        entityTransaction.begin();
        int updatedRows = entityManager.createQuery(jpql)
                .setParameter(1, student.getTotalFine())
                .setParameter(2, student.getStudId())
                .executeUpdate();

        if (updatedRows == 1) {
            entityTransaction.commit();
            return "Fine Updated";
        } else {
            entityTransaction.rollback();
            return "Student with ID " + student.getStudId() + " not found";
        }
    }

    @Override
    public String updateStudent(Student student) {
        String jpql = "update Student s set s.studName = :studName, s.studEmail = :studEmail, " +
                "s.studContactNo = :studContactNo, s.studAddress = :studAddress, " +
                "s.studPassword = :studPassword where s.studId = :studId";

        entityTransaction.begin();
        int updatedRows = entityManager.createQuery(jpql)
                .setParameter("studName", student.getStudName())
                .setParameter("studEmail", student.getStudEmail())
                .setParameter("studContactNo", student.getStudContactNo())
                .setParameter("studAddress", student.getStudAddress())
                .setParameter("studPassword", student.getStudPassword())
                .setParameter("studId", student.getStudId())
                .executeUpdate();

        if (updatedRows == 1) {
            entityTransaction.commit();
            return "Student information updated";
        } else {
            entityTransaction.rollback();
            return "Student with ID " + student.getStudId() + " not found";
        }
    }

//    @Override
//    public Student inputGetStudentByUserName(String username) {
//        String jpql = "select s from Student s where s.username LIKE :username";
//        query = entityManager.createQuery(jpql);
//        query.setParameter("username", "%" + username + "%");
//        List<Student> list1 = query.getResultList();
//        return list1;
//    }

}
