package com.project.library.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer studId;
    @Column(length = 20)
    private String studName;
    @Column(length = 20)
    private String username;
    @Column(length = 20)
    private String studEmail;
    @Column(length = 20)
    private String studContactNo;
    @Column(length = 20)
    private String studAddress;
    @Column(length = 20)
    private String studPassword;
    private Double totalFine = 0.0;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "student")
    private List<BookIssue> bookIssue;



















    public Integer getStudId() {
        return studId;
    }

    public void setStudId(Integer studId) {
        this.studId = studId;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStudEmail() {
        return studEmail;
    }

    public void setStudEmail(String studEmail) {
        this.studEmail = studEmail;
    }

    public String getStudContactNo() {
        return studContactNo;
    }

    public void setStudContactNo(String studContactNo) {
        this.studContactNo = studContactNo;
    }

    public String getStudAddress() {
        return studAddress;
    }

    public void setStudAddress(String studAddress) {
        this.studAddress = studAddress;
    }

    public String getStudPassword() {
        return studPassword;
    }

    public void setStudPassword(String studPassword) {
        this.studPassword = studPassword;
    }

    public Double getTotalFine() {
        return totalFine;
    }

    public void setTotalFine(Double totalFine) {
        totalFine = totalFine;
    }

    public List<BookIssue> getBookIssue() {
        return bookIssue;
    }

    public void setBookIssue(List<BookIssue> bookIssue) {
        this.bookIssue = bookIssue;
    }
}