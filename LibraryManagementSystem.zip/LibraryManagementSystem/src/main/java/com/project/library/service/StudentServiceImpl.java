package com.project.library.service;

import com.project.library.dao.StudentDao;
import com.project.library.dao.StudentDaoImpl;
import com.project.library.entity.Student;

public class StudentServiceImpl implements StudentService{
    StudentDao studentDao = new StudentDaoImpl();
    @Override
    public String registerStudent(Student student) {

        return studentDao.registerStudent(student);
    }

    @Override
    public Student getStudentById(Integer studId) {

        return studentDao.getStudentById(studId);
    }

    @Override
    public String updateStudent(Student student) {
        Student existingStudent = studentDao.getStudentById(student.getStudId());
        if (existingStudent == null) {
            return "Student not found.";
        }
        String existingStudent1 = studentDao.updateStudent(student);
        boolean success = Boolean.parseBoolean(existingStudent1);

        if (success) {
            return "Student information updated successfully.";
        } else {
            return "Failed to update student information.";
        }
    }


//    @Override
//    public Student inputGetStudentByUserName(String username) {
//        return studentDao.inputGetStudentByUserName(username);
//    }

//    @Override
//    public BookIssue getBookIssuedById(Integer issueId) {
//        return null;
//    }
}
