package com.project.library.dao;

import com.project.library.entity.Book;

import java.util.List;

public interface BookDao
{

    String registeredBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Integer bookId);

    List<Book> getAllBookByName(String bookName);
    List<Book> getAllBookByType(String bookType);

    List<Book> getAllBooksByAuthor(String authorName);
    public  String updateStock(Book book);

    /*
    String confirmBookIssue(int bookId, int studentId);

    List<Book> displayUnreturnedBooks();
    List<Book> displayUnissuedBooks();
    List<Book> displayFinedetails();
    String registeredStudent(Student student);
    Book searchBook(String title);
    String returnBook(int bookId, int studentId);
    String issueBook(int bookId, int studentId);
    String payFine(int studentId);
    List<Student> viewFineDetails();
    Student viewProfile(int studentId);
    List<Book> showAllBooks();
    List<Book> viewBorroweddetails(int studentId);
    */
}
