package com.project.library.presentation;


import com.project.library.dao.StudentDao;
import com.project.library.dao.StudentDaoImpl;
import com.project.library.entity.Admin;
import com.project.library.entity.Book;
import com.project.library.entity.Student;
import com.project.library.entity.BookIssue;
import com.project.library.service.*;
import java.time.temporal.ChronoUnit;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;



public class BookIssueUserImpl implements BookIssueUser {
    private static Scanner sc = new Scanner(System.in);
    private static BookIssueService bookIssueService = new BookIssueServiceImpl();
    private static BookService bookService = new BookServiceImpl();
    private static StudentService studentService = new StudentServiceImpl();
    private static StudentDao studentDao = new StudentDaoImpl();
    private Student student =new Student();
    private BookIssue bookIssue = new BookIssue();
    private static Integer bookId;
    private static Integer studId;

    @Override
    public List<BookIssue> inputIssueBook(Integer studId) {
        System.out.println("BookIssueUserImpl" + studId);
        System.out.println("Enter the book Id");
        bookId = sc.nextInt();

        Book book1 = bookService.getBookById(bookId);
        Student student1 = studentService.getStudentById(studId);
        BookIssue bookIssue = new BookIssue();
        bookIssue.setBook(book1);
        bookIssue.setStudent(student1);
        bookIssue.setIssueDate(bookIssue.getIssueDate());
        bookIssue.setDueDate(bookIssue.getDueDate());
        //bookIssue.setReturnDate(bookIssue.getReturnDate());
        bookIssue.setBookStatus(bookIssue.getBookStatus());
        bookIssue.setFine(bookIssue.getFine());
        System.out.println(bookIssueService.issueBook(bookIssue));


        return null;
    }

    @Override
    public void inputReturnBook()
    {
        StudentUserImpl studentUser = new StudentUserImpl();
        studentUser.viewBorrowedDetails();

        System.out.println("Enter the Issue ID to return the book:");
        int issueId = sc.nextInt();

        BookIssue bookIssue = bookIssueService.getBookIssuedById(issueId);

        if (bookIssue != null && !"Book Returned".equals(bookIssue.getBookStatus())) {

            sendReturnRequestNotification(bookIssue);

            bookIssue.setReturnDate(LocalDate.now());
            bookIssue.setBookStatus("Return Requested");

            System.out.println("Return request sent to admin. Waiting for approval...");

        } else {
            System.out.println("Invalid Issue ID / the book has already been returned.");
        }

    }

    public void sendReturnRequestNotification(BookIssue bookIssue) {

        System.out.println("Return request received for Book ID: " + bookIssue.getBook().getBookId());
        System.out.println("Student ID: " + bookIssue.getStudent().getStudId());
        System.out.println("Please review and approve the return.");
    }

    public void updateStockOnReturn() {

        System.out.println("Enter Book Issue ID:");
        Integer issueId = sc.nextInt();

        BookIssue bookIssue = bookIssueService.getBookIssuedById(issueId);

        if (bookIssue != null) {
            Book book = bookIssue.getBook();

            if (book != null) {
                System.out.println("Current Stock Quantity: " + book.getQuantity());

                book.setQuantity(book.getQuantity() + 1);
                System.out.println(bookService.updateStock(book));

                bookIssue.setBookStatus("Book Returned");
                LocalDate returnDate = LocalDate.now();
                bookIssue.setReturnDate(returnDate);
                System.out.println("Book Returned successfully!");

                bookIssueService.returnBook(bookIssue);
            } else {
                System.out.println("Invalid Book ID.");
            }
        } else {
            System.out.println("Invalid Book Issue ID.");
        }
    }
    @Override
    public void inputGetIssuedBook() {
        List<BookIssue> l = bookIssueService.getIssuedBook();
        Iterator<BookIssue> itr = l.iterator();
        System.out.println("---------------------------------------------------------------");
        System.out.printf("%-15s | %-18s | %-10s | %-8s%n", "IssueId", "IssueDate", "ReturnDate", "DueDate", "BookStatus");
        System.out.println("---------------------------------------------------------------");

        while (itr.hasNext()) {
            BookIssue b = itr.next();
            System.out.printf("%-15s | %-18s | %-10s | %-8s%n", b.getIssueId(), b.getIssueDate(), b.getReturnDate(), b.getDueDate(), b.getBookStatus());
        }

    }

    @Override
    public void inputgetBookIssuedById() {
        System.out.println("Enter the BookIssue Id:");
        Integer issueId = sc.nextInt();

        if (issueId != null) {
            BookIssue bookIssue = bookIssueService.getBookIssuedById(issueId);

            if (bookIssue != null) {
                System.out.println("Book Id is: " + bookIssue.getIssueId());
                System.out.println("Book Name is: " + bookIssue.getIssueDate());
                System.out.println("Book Auther Name is: " + bookIssue.getReturnDate());
                System.out.println("Book Quentity is: " + bookIssue.getDueDate());
                System.out.println("Book Type is: " + bookIssue.getBookStatus());
            } else {
                System.out.println("BookIssued not found......");
            }
        } else {
            System.out.println("Invalid BookIssue Id......");
        }

    }

    @Override
    public void inputConfirmIssueBook(Admin admin) {
        displayUnissuedBook();
        System.out.println("Do you want to Issued any book to the student (yes/no) : ");
        String ans = sc.next();
        Integer issueId = null;


        if (ans.equalsIgnoreCase("yes")) {
            System.out.println("Enter issued Id: ");
            issueId = sc.nextInt();

            BookIssue bookIssue = bookIssueService.findRecordByIssueId(issueId);

            bookIssue.setIssueDate(LocalDate.now());
            bookIssue.setDueDate(LocalDate.now().plusDays(5));
            //bookIssue.setDueDate(LocalDate.now());

            bookIssue.setBookStatus("ISSUED");
            bookIssue.setAdmin(admin);

            Book book = bookService.getBookById(bookIssue.getBook().getBookId());
            book.setQuantity(book.getQuantity()-1);
            bookService.updateStock(book);
            System.out.println(bookIssueService.confirmIssueBook(bookIssue));

        }
    }


    @Override
    public void displayUnissuedBook() {

        LocalDate returnDate = null;
        List<BookIssue> list = bookIssueService.displayUnissuedBook();
    }

//    @Override
//    public void displayAllFineStudent()
//    {
//        //bookIssueService.displayAllFineStudent();
//        List<BookIssue> bookIssues = bookIssueService.displayAllFineStudent();
//        bookIssueService.unReturnedBooks();
//        System.out.println("\n");
//        System.out.printf("%-15s | %-20s | %-10s | %-15s%n",
//                "Student ID", "Student Name", "Fine Amount", "Due Date");
//
//        for (BookIssue bookIssue : bookIssues) {
//            Student student = bookIssue.getStudent();
//            LocalDate dueDate = bookIssue.getDueDate();
//            LocalDate returnDate = bookIssue.getReturnDate();
//            String bookStatus = bookIssue.getBookStatus();
//
//            if (!"Book Returned".equals(bookStatus) && LocalDate.now().isAfter(dueDate)) {
//                long daysLate = Math.max(0, ChronoUnit.DAYS.between(dueDate, LocalDate.now()));
//                double fineAmount = daysLate * 5.0;
//
//                System.out.printf("%-15s | %-20s | %-10.2f | %-15s%n",
//                        student.getStudId(), student.getStudName(), fineAmount, dueDate);
//            }
//        }
//    }

    @Override
    public void unReturnedBooks() {

        List<BookIssue> list = bookIssueService.unReturnedBooks();
    }
    @Override
    public List<BookIssue> unReturnedBooksByStudent()
    {
        List<BookIssue> list = bookIssueService.unReturnedBooksByStudent();

        return list;
    }

    @Override
    public void payFine() {
        BookIssue bookIssue = new BookIssue();
        List<BookIssue> issuedBooks = bookIssueService.displayAllFineStudent();

        if (issuedBooks == null || issuedBooks.isEmpty()) {
            System.out.println("No books are currently issued.");
        } else {
            System.out.println("Fine Details:");

            for (BookIssue bookIssue1 : issuedBooks) {
                if (bookIssue.getDueDate() != null && bookIssue.getReturnDate() != null
                        && bookIssue.getReturnDate().isAfter(bookIssue.getDueDate())) {
                    long daysLate = ChronoUnit.DAYS.between(bookIssue.getDueDate(), bookIssue.getReturnDate());
                    double fine = daysLate * 0.5;

                    System.out.println("Issue ID: " + bookIssue1.getIssueId());
                    System.out.println("Book ID: " + bookIssue1.getBook().getBookId());
                    System.out.println("Student ID: " + bookIssue1.getStudent().getStudId());
                    System.out.println("Book Name: " + bookIssue1.getBook().getBookName());
                    System.out.println("Student Name: " + bookIssue1.getStudent().getStudName());
                    System.out.println("Due Date: " + bookIssue1.getDueDate());
                    System.out.println("Return Date: " + bookIssue1.getReturnDate());
                    System.out.println("Days Late: " + daysLate);
                    System.out.println("Fine Amount: $" + fine);
                    System.out.println();
                }
            }
        }


    }

    @Override
    public void displayAllFineStudent() {
        List<BookIssue> unreturnedBooks = bookIssueService.displayAllFineStudent();

        if (unreturnedBooks.isEmpty()) {
            System.out.println("No fines to display.");
        } else {
            System.out.println("Fine Details:");
            System.out.printf("%-15s | %-20s | %-10s | %-15s%n",
                    "Student ID", "Student Name", "Fine Amount", "Due Date");

            for (BookIssue bookIssue : unreturnedBooks) {
                Student student = bookIssue.getStudent();
                LocalDate dueDate = bookIssue.getDueDate();
                LocalDate returnDate = bookIssue.getReturnDate();
                String bookStatus = bookIssue.getBookStatus();

                if (!"Book Returned".equals(bookStatus) && LocalDate.now().isAfter(dueDate)) {
                    long daysLate = Math.max(0, ChronoUnit.DAYS.between(dueDate, LocalDate.now()));
                    double fineAmount = daysLate * 5.0;

                    System.out.printf("%-15s | %-20s | %-10.2f | %-15s%n",
                            student.getStudId(), student.getStudName(), fineAmount, dueDate);
                }
            }
        }

           }

    private int calculateFine(LocalDate dueDate, LocalDate returnDate) {
        int fine = 0;

        if (dueDate != null && returnDate != null) {
            if (dueDate.isEqual(returnDate)) {
                fine = 0;
            } else if (returnDate.isBefore(dueDate)) {
                fine = 0;
            } else {
                long daysDifference = ChronoUnit.DAYS.between(dueDate, returnDate);
                fine = (int) (daysDifference * 5);
            }
        }

        return fine;
    }


    public void viewBorrowedDetails(Integer studId) {
        List<BookIssue> borrowedBooks = bookIssueService.getIssuedBook();

        if (borrowedBooks.isEmpty()) {
            System.out.println("You have not borrowed any books.");
        } else {
            System.out.println("Borrowed Book Details:");
            System.out.printf("%-15s | %-20s | %-15s | %-15s | %-15s%n",
                    "Book ID", "Book Name", "Issue Date", "Due Date", "Return Date");

            for (BookIssue bookIssue : borrowedBooks) {
                Book book = bookIssue.getBook();
                LocalDate issueDate = bookIssue.getIssueDate();
                LocalDate dueDate = bookIssue.getDueDate();
                LocalDate returnDate = bookIssue.getReturnDate();

                System.out.printf("%-15s | %-20s | %-15s | %-15s | %-15s%n",
                        book.getBookId(), book.getBookName(), issueDate, dueDate,
                        (returnDate != null) ? returnDate : "Not Returned");
            }
        }
    }



}










