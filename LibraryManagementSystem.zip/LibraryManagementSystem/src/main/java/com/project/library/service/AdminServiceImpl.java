package com.project.library.service;

import com.project.library.dao.AdminDao;
import com.project.library.dao.AdminDaoImpl;
import com.project.library.entity.Admin;

import java.util.List;

public class AdminServiceImpl implements AdminService{
    private static AdminDao  adminDao = new AdminDaoImpl();
    @Override
    public String registerAdmin(Admin admin) {
        return adminDao.registerAdmin(admin);
    }

    @Override
    public Admin getAdminById(Integer adminId) {

        return adminDao.getAdminById(adminId);
    }

    @Override
    public String updateAdminInfo(Integer adminId) {
        return adminDao.updateAdminInfo(adminId);
    }

    @Override
    public List<Admin> showAllAdmin() {
        return adminDao.showAllAdmin();
    }

    @Override
    public Admin deleteAdmin(Integer adminId) {
        return adminDao.deleteAdmin(adminId);
    }
}
