package com.project.library.service;

import com.project.library.entity.Book;

import java.util.List;

public interface BookService
{
    String registeredBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Integer bookId);
    List<Book> getAllBookByName(String bookName);
    List<Book> getAllBookByType(String bookType);
    public  String updateStock(Book book);

    List<Book> getAllBooksByAuthor(String authorName);

	/*
    String confirmBookIssue(int bookId, int studentId);
    List<Book> displayUnreturnedBooks();
    List<Book> displayUnissuedBooks();+
    List<Book> displayFinedetails();
    String registeredStudent(Student student);
    Book searchBook(String title);
    String returnBook(int bookId, int studentId);
    String issueBook(int bookId, int studentId);
    String payFine(int studentId);
    List<Student> viewFineDetails();
    Student viewProfile(int studentId);
    List<Book> showAllBooks();
    List<Book> viewBorroweddetails(int studentId);
    */
}
