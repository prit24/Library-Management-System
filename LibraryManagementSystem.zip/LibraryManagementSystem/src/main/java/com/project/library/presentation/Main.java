package com.project.library.presentation;

import com.project.library.entity.Admin;
import com.project.library.entity.Student;
import com.project.library.service.BookService;
import com.project.library.service.BookServiceImpl;

import java.awt.print.Book;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) {



        BookIssueUser bookIssueUser = new BookIssueUserImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("╔════════════════════════════════════════╗");
            System.out.println("║      Welcome Dev Queen's to Library    ║");
            System.out.println("║                                        ║");
            System.out.println("╚════════════════════════════════════════╝");
            displayMainMenu();
            System.out.print("\nChoose Portal Admin/Student : ");
            int choice = sc.nextInt();


// Login and Ragister switch ----------------------------------------------------------------------------------
            switch (choice) {
                case 1:

                    AdminUser adminUser = new AdminUserImpl();
                    System.out.println("\n******** Welcome to Admin Portal ********");
                    System.out.println("1. Admin Register");
                    System.out.println("2. Admin Login");
                    System.out.println("3. Logout");
                    System.out.print("\nEnter your choice: ");
                    int choice1 = sc.nextInt();
                    switch (choice1)
                    {
                        case 1 :
                            adminUser.registerAdmin();
                            Admin logInAdmin = adminUser.inputAdminLogin();
                            if (logInAdmin != null)
                            {
                                adminActions(sc);
                            }
                            break;
                        case 2:
                            Admin logInAdmin1 = adminUser.inputAdminLogin();
                            if (logInAdmin1 != null)
                            {
                                adminActions(sc);
                            }
                            break;
                        case 3:
                            System.out.println("Logout....");
                            break;
                    }


                    break;
                case 2:

                    StudentUser studentUser = new StudentUserImpl();
                    System.out.println("\n ******** Welcome to Student Portal ********");
                    System.out.println("1. Student Register");
                    System.out.println("2. Student Login");
                    System.out.println("3. Logout");
                    System.out.print("\nEnter your choice: ");
                    int choice2 = sc.nextInt();
                        switch (choice2)
                        {
                            case 1 :     studentUser.registerStudent();
                                Student LogInStudent = studentUser.inputStudentLogin();
                                if (LogInStudent != null) {
                                    studentActions(sc);
                                }
                                break;
                            case 2:

                                Student LogInStudent1 = studentUser.inputStudentLogin();

                                if (LogInStudent1 != null) {
                                    studentActions(sc);
                                }
                                break;
                            case 3:
                                System.out.println("Logout.....");
                                break;
                        }


                    break;
                case 3:
                    System.out.println("Exiting the program. Goodbye...!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice... \nPlease enter a valid option.");
                    break;
            }
        }
    }
// close Login and Ragister switch ----------------------------------------------------------------------------------


    private static void displayMainMenu() {
        System.out.println("\n+---------------- Main Menu ----------------+");
        System.out.println("|                                              |");
        System.out.println("|                1. Admin                      |");
        System.out.println("|                2. Student                    |");
        System.out.println("|                3. Exit                       |");
        System.out.println("|                                              |");
        System.out.println("+----------------------------------------------+");

    }


// Admin Actions  ----------------------------------------------------------------------------------
    private static void adminActions(Scanner scanner) {
        while (true) {
            System.out.println("\n~~~~~~~~Welcome Page to admin~~~~~~~~~~");
            System.out.println("1. Add new Book");
            System.out.println("2. Update Stock");
            System.out.println("3. Display Book");
            System.out.println("4. approved Book Issue");
            System.out.println("5. Display Unreturned Books");
            System.out.println("6. Display Unissued Books ");
            System.out.println("7. Display issued Books ");
            System.out.println("8. Display Fine details");
            System.out.println("9. Logout");

            System.out.print("\nEnter your choice for Admin: ");
            int subChoice = scanner.nextInt();

            AdminUser adminUser = new AdminUserImpl();
            BookUser bookUser = new BookUserImpl();
            BookIssueUser bookIssueUser = new BookIssueUserImpl();


            // admin switch -----------------

            switch (subChoice) {
                case 1:
                    System.out.println("Register Book");
                    bookUser.inputRegisteredBook();
                    break;
                case 2:
                    System.out.println("Update Book");
                    bookUser.inputUpdateStock();
                    break;
                case 3:

                    System.out.println("\n------------Menu-----------");
                    System.out.println("1. View All Books ");
                    System.out.println("2. Search by Book Name");
                    System.out.println("3. Search by Book Type");
                    System.out.println("4. Search by Author");
                    System.out.println("5.Logout ");
                    System.out.print("\nPlease enter your choice (1-5) : ");
                    int choice1 = scanner.nextInt();

                    // display book for admin switch ---------------------

                    switch (choice1)
                    {
                        case 1:bookUser.inputGetAllBooks();
                            break;
                        case 2:bookUser.inputGetBookByName();
                            break;
                        case 3:bookUser.inputGetBookByType();
                            break;
                        case 4:bookUser.inputGetBookByAuther();
                            break;
                        case 5:
                            System.out.println("Logout");
                            return;
                    }
                    break;

                // display book for admin switch ---------------------

                case 4:
                    System.out.println("approved Book Issue");
                    adminUser.inputConfirmIssueBook();

                    break;
                case 5:
                    System.out.println("Display Unreturned Books");
                    bookIssueUser.unReturnedBooks();
                    bookIssueUser.updateStockOnReturn();

                    break;
                case 6:
                    System.out.println("Display Unissued Books");
                    bookIssueUser.displayUnissuedBook();
                    break;
                case 7:
                    System.out.println("Display issued Books");
                    bookIssueUser.inputGetIssuedBook();
                    break;
                case 8:
                    System.out.println(" Display Fine details");
                    bookIssueUser.displayAllFineStudent();
                    break;
                case 9:
                    System.out.println("Logout");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
    // close admin switch -------------------------------











    //--------  student action start --------------------------------
    private static void studentActions(Scanner scanner) {
        while (true) {
            System.out.println("\n~~~~~~~~~~~~~Welcome Page to Student~~~~~~~~~~~~~~~~\n");
            System.out.println("1. Update Student");
            System.out.println("2. Search Book");
            System.out.println("3. Request Issue Book");
            System.out.println("4. Request Admin to Return book");
            System.out.println("5. Pay fine");
            System.out.println("6. View fine details");
            System.out.println("7. View profile");
            System.out.println("8. View Borrowed Details");
            System.out.println("9. Logout");

            System.out.print("\nEnter your choice for Student: ");
            int subChoice = scanner.nextInt();

            StudentUser studentUser = new StudentUserImpl();
            BookIssueUser bookIssueUser = new BookIssueUserImpl();
            BookUser  bookUser = new BookUserImpl();

            switch (subChoice) {
                case 1:
                    studentUser.updateStudent();
                    break;
                case 2:
                    System.out.println("\n------------Menu-----------");
                    System.out.println("1. View All Books ");
                    System.out.println("2. Search by Book Name");
                    System.out.println("3. Search by Book Type");
                    System.out.println("4. Search by Author");
                    System.out.println("5.Logout ");
                    System.out.print("\nPlease enter your choice (1-5) : ");
                    int choice1 = scanner.nextInt();

                    // display book for Student switch ---------------------

                    switch (choice1)
                    {
                        case 1:bookUser.inputGetAllBooks();
                            break;
                        case 2:bookUser.inputGetBookByName();
                            break;
                        case 3:bookUser.inputGetBookByType();
                            break;
                        case 4:bookUser.inputGetBookByAuther();
                            break;
                        case 5:
                            System.out.println("Logout");
                            return;
                    }
                    break;

                // display book for Student switch ---------------------

                case 3:
                    System.out.println("Issue book");
                    studentUser.bookIssue();
                    break;
                case 4:
                    System.out.println("Request Admin to Return book");
                    bookIssueUser.inputReturnBook();

                    break;
                case 5:
                    System.out.println("Input get Issue  Book");
                    bookIssueUser.inputGetIssuedBook();
                    break;
                case 6:
                    System.out.println("View fine details");

                    break;
                case 7:
                    System.out.println("View profile");
                    studentUser.getStudentById();
                    break;

                case 8:
                    System.out.println("View Borrowed Details");
                    studentUser.viewBorrowedDetails();
                    //studentUser.viewBorrowedDetails(studentUser.getStudentById());

                    break;
                case 9:
                    System.out.println("Logging out from Student. Returning to Main Menu.");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
