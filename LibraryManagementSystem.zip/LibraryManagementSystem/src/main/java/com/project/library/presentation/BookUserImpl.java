package com.project.library.presentation;


import com.project.library.entity.Book;
import com.project.library.service.BookService;
import com.project.library.service.BookServiceImpl;

import java.util.List;
import java.util.Scanner;

import static java.lang.System.out;

public class BookUserImpl implements BookUser{
    private Scanner sc = new Scanner(System.in);
    private BookService bookService=new BookServiceImpl();

    @Override
    public void inputRegisteredBook()
    {
        System.out.println("Enter Book Name:");
        String bookName = sc.nextLine();

        System.out.println("Enter Book Author Name:");
        String author = sc.nextLine();

        System.out.println("Enter Book Type:");
        String bookType = sc.nextLine();

        System.out.println("Enter Book Status:");
        String bookStatus = sc.nextLine();

        System.out.println("Enter Book Quantity:");
        Integer quantity = sc.nextInt();

        Book book = new Book();
        book.setBookName(bookName);
        book.setAuthorName(author);
        book.setBookType(bookType);
       // book.setBookStatus(bookStatus);
        book.setQuantity(quantity);
        book.setBookIssue(null);

        System.out.println(bookService.registeredBook(book));

    }

    @Override
    public void inputGetAllBooks()
    {
        List<Book> allBooks = bookService.getAllBooks();

        if (!((List<?>) allBooks).isEmpty()) {
            System.out.println("All Books:");
            for (Book book : allBooks) {
                System.out.println("Book Details : ");
                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        "Book ID", "Book Name", "Author", "Quantity", "Type", "Book Status");

                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        book.getBookId(), book.getBookName(), book.getAuthorName(),
                        book.getQuantity(), book.getBookType(), book.getBookStatus());
                System.out.println("----------------------");
            }
        } else {
            System.out.println("No books available.");
        }

    }

    @Override
    public void inputGetBookById()
    {
        System.out.println("Enter Book ID:");
        int bookId = sc.nextInt();
        Book book = bookService.getBookById(bookId);


        if (book != null) {
            System.out.println("Book Details:");
            System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                    "Book ID", "Book Name", "Author", "Quantity", "Type", "Book Status");

            System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                    book.getBookId(), book.getBookName(), book.getAuthorName(),
                    book.getQuantity(), book.getBookType());

        } else {
            System.out.println("Book not found with ID: " + bookId);
        }


    }

    @Override
    public void inputGetBookByName()
    {
        System.out.println("Enter Book Name:");
        String bookName = sc.next();

        List<Book> booksByName = bookService.getAllBookByName(bookName);


        if (!booksByName.isEmpty()) {
            System.out.println("Books with Name '" + bookName + "':");
            for (Book book : booksByName) {
                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        "Book ID", "Book Name", "Author", "Quantity", "Type", "Book Status");

                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        book.getBookId(), book.getBookName(), book.getAuthorName(),
                        book.getQuantity(), book.getBookType());
            }
        } else {
            System.out.println("No books found with the name: " + bookName);
        }

    }

    @Override
    public void inputGetBookByType()
    {
        System.out.println("Enter Book Type:");
        String bookType = sc.next();
        List<Book> booksByType = bookService.getAllBookByType(bookType);


        if (!booksByType.isEmpty()) {
            System.out.println("Books of Type '" + bookType + "':");
            for (Book book : booksByType) {
                System.out.println("Book Details:");
                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        "Book ID", "Book Name", "Author", "Quantity", "Type", "Book Status");

                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        book.getBookId(), book.getBookName(), book.getAuthorName(),
                        book.getQuantity(), book.getBookType());
            }
        } else {
            System.out.println("No books found with the type: " + bookType);
        }

    }

    @Override
    public void inputGetBookByAuther()
    {
        System.out.println("Enter Author Name:");
        String authorName = sc.next();
        List<Book> books = bookService.getAllBooksByAuthor(authorName);

        if (books.isEmpty()) {
            System.out.println("No books found by the author: " + authorName);
            System.out.println("Book not found...");

            }
        else {
            for (Book book : books) {
                System.out.println("Book Details:");
                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        "Book ID", "Book Name", "Author", "Quantity", "Type", "Book Status");

                System.out.printf("%-10s | %-30s | %-20s | %-8s | %-15s | %-15s%n",
                        book.getBookId(), book.getBookName(), book.getAuthorName(),
                        book.getQuantity(), book.getBookType());

            }
        }
    }

    @Override
    public void inputUpdateStock()
    {
        System.out.println("Enter Book ID:");
        Integer bookId = sc.nextInt();

        System.out.println("Enter Quantity to Add:");
        Integer quantity = sc.nextInt();
        Book book=new Book();
        System.out.println("Current Stock Quantity: " + book.getQuantity());
        book.setBookId(bookId);
        book.setQuantity(quantity);

        System.out.println(bookService.updateStock(book));
    }
}