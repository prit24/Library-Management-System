package com.project.library.dao;

import com.project.library.entity.Admin;
import com.project.library.entity.Book;
import com.project.library.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.List;

public class AdminDaoImpl implements AdminDao{
    private static EntityManager entityManager=MyConnection.getEntityManagerObject();
    private static EntityTransaction entityTransaction=entityManager.getTransaction();
    Query query;
    @Override
    public String registerAdmin(Admin admin) {
        entityTransaction.begin();
        entityManager.persist(admin);
        entityTransaction.commit();

        return "Admin Registration  done\nAdminId :"+ admin.getAdminId();

    }

    @Override
    public Admin getAdminById(Integer adminId) {

        return entityManager.find(Admin.class, adminId);
    }

    @Override
    public String updateAdminInfo(Integer adminId) {
        return null;
    }

    @Override
    public List<Admin> showAllAdmin() {
        String jpql="select a from Admin a";
        query=entityManager.createQuery(jpql);
        List<Admin> list=query.getResultList();
        return list;
    }

    @Override
    public Admin deleteAdmin(Integer adminId) {
        entityTransaction.begin();
        entityManager.remove(adminId);
        entityTransaction.commit();
        return null;
    }
}
