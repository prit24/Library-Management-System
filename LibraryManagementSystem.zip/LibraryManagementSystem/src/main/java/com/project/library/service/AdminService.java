package com.project.library.service;

import com.project.library.entity.Admin;

import java.util.List;

public interface AdminService
{
    String registerAdmin(Admin admin);
    Admin getAdminById(Integer adminId);
    String updateAdminInfo(Integer adminId);
    List<Admin> showAllAdmin();
    Admin deleteAdmin(Integer adminId);
}
