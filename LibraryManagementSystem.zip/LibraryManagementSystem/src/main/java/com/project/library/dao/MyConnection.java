package com.project.library.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class MyConnection
{

    private MyConnection()
    {

    }

    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;

    public static EntityManager getEntityManagerObject() {
        if(entityManager== null) {
            entityManagerFactory = Persistence.createEntityManagerFactory("raj");
            entityManager=entityManagerFactory.createEntityManager();

        }
        return entityManager;

    }
}
