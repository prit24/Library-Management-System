package com.project.library.service;

import com.project.library.entity.Student;

public interface StudentService
{
    String registerStudent(Student student);
    Student getStudentById(Integer studId);

    String updateStudent(Student student);
    //Student inputGetStudentByUserName(String username);
    //BookIssue getBookIssuedById(Integer issueId);
}
