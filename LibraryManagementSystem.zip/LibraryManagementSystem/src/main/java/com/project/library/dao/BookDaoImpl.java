package com.project.library.dao;

import com.project.library.entity.Book;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.List;

public class BookDaoImpl implements BookDao {
    private static EntityManager entityManager=MyConnection.getEntityManagerObject();
    private static EntityTransaction entityTransaction=entityManager.getTransaction();
    Query query;

    @Override
    public String registeredBook(Book book) {
        entityTransaction.begin();
        entityManager.persist(book);
        entityTransaction.commit();
        return "Book Registered";
    }

    @Override
    public List<Book> getAllBooks() {
        String jpql="select b from Book b";
        query=entityManager.createQuery(jpql);
        List<Book> list=query.getResultList();
        return list;
    }

    @Override
    public Book getBookById(Integer bookId) {
        Book book=entityManager.find(Book.class, bookId);
        return book;
    }

    @Override
    public String updateStock(Book book) {
        entityTransaction.begin();
        query = entityManager.createQuery("update Book b set b.quantity = ?1 where b.bookId = ?2");
        query.setParameter(1, book.getQuantity());
        query.setParameter(2, book.getBookId());
        query.executeUpdate();
        entityTransaction.commit();
        entityManager.clear();
        return "Stock Updated";
    }



    @Override
    public List<Book> getAllBookByName(String bookName) {
        String jpql = "select b from Book b where b.bookName LIKE :bookName";
        query = entityManager.createQuery(jpql);
        query.setParameter("bookName", "%" + bookName + "%");
        List<Book> list = query.getResultList();
        return list;
//        String jpql="select b from Book b where b.bookName like "+bookName+"%";
//        query=entityManager.createQuery(jpql);
//        List<Book> list=query.getResultList();
//        return list;
    }

    @Override
    public List<Book> getAllBookByType(String bookType)
    {
        String jpql = "select b from Book b where b.bookType LIKE :bookType";
        query = entityManager.createQuery(jpql);
        query.setParameter("bookType",  "%" + bookType + "%");
        List<Book> list = query.getResultList();
        return list;
//        String jpql="select b from Book b where b.bookType=?1";
//        query=entityManager.createQuery(jpql);
//        query.setParameter(1, bookType);
//        List<Book> list=query.getResultList();
//        return list;
    }

    @Override
    public List<Book> getAllBooksByAuthor(String authorName)
    {
        String jpql = "select b from Book b where b.authorName LIKE :authorName";
        query = entityManager.createQuery(jpql);
        query.setParameter("authorName",  "%" + authorName + "%");
        List<Book> list = query.getResultList();
        return list;
//        String jpql="select b from Book b where b.authorName=?1";
//        query=entityManager.createQuery(jpql);
//        query.setParameter(1, authorName);
//        List<Book> list=query.getResultList();
//        return list;
    }
}

