package com.project.library.dao;

import com.project.library.entity.BookIssue;
import com.project.library.entity.Student;
import com.project.library.presentation.BookUser;

import java.util.List;

public interface BookIssueDao
{
    public String issueBook(BookIssue bookIssue);
    String returnBook(BookIssue bookIssue);
    BookIssue getBookIssuedById(Integer issueId);
    List<BookIssue> getIssuedBook();
    List<BookIssue> displayUnissuedBook();
    BookIssue findRecordByIsuueId(Integer issueId);
    String confirmIssueBook(BookIssue bookIssue);
    List<BookIssue>  displayAllFineStudent();
    List<BookIssue> payFine();
    public List<BookIssue> unReturnedBooks();
    public List<BookIssue> unReturnedBooksByStudent(Student student);
}
